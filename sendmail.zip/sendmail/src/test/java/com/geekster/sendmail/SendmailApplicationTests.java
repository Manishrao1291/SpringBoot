package com.geekster.sendmail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SendmailApplicationTests {

	@Test
	void contextLoads() {
	}

}
